# 愈深愈肉（Deeper and Tankier）

杀戮尖塔 2（Slay the Spire 2）模组：**怪物血量随爬塔层数增加**——爬得越深，怪物越肉。

- 模组 ID：`DeeperAndTankier`
- 版本：0.1.0
- 适用游戏版本：v0.111.0（`min_game_version: 0.111.0`）
- 依赖：无（仅使用游戏自带的 Harmony 与模组加载器）
- `affects_gameplay: true`（影响玩法；联机时所有玩家需安装同版本模组）

---

## 一、公式

```
增幅   = 0.001 × 难度 × 层数
血量倍率 = 1 + 增幅
```

- **难度** = 本局的进阶等级 A（`RunState.AscensionLevel`，A10 → 10）
- **层数** = 本局已爬的**总层数**（`RunState.TotalFloor`，跨幕累计，就是结算界面
  “爬塔层数 / floors climbed”那个数）

> **注意：层数 ≠ 幕数。**
> 幕数是 `CurrentActIndex`（第几幕），本模组不用它；
> 也不用幕内层数 `ActFloor`（每幕从 1 重新数）。
> 本模组用的是全局累计层数，越深越肉，跨幕持续增长。

### 示例

| 场景 | 计算 | 血量倍率 |
|---|---|---|
| A10，第 16 层 | 0.001 × 10 × 16 = 16% | ×1.16 |
| A20，第 50 层 | 0.001 × 20 × 50 = 100% | ×2.00 |
| A0（无进阶） | — | ×1.00（不加成） |
| 任意难度，第 0 层 | — | ×1.00（不加成） |

血量换算后**向下取整**（与原版多人血量缩放的取整方式一致，联机各端结果必定相同）。

---

## 二、多人模式

原版多人已有一个人数/幕数血量机制：

```
原版多人血量 = 原始血量 × 人数 × 按幕数系数
按幕数系数：幕一 1.1 ／ 幕二 1.2 ／ 幕三 Boss 1.3，其余 1.2
（见 Creature.ScaleHpForMultiplayer / MultiplayerScalingModel.GetMultiplayerScaling）
```

本模组的倍率**乘在其结果之上**，两者互不覆盖、纯乘算共存：

```
最终血量 = 原始血量 × 人数 × 按幕数系数 × (1 + 0.001 × 难度 × 层数)
```

例：**A10、第 16 层、2 人、幕一** → `原始血量 × 2 × 1.1 × 1.16`，
即在原版多人血量基础上再 +16%。

联机适配说明：

- 公式只读取共享的 `RunState`（层数、难度），不读任何本地/随机状态，
  联机各端计算结果完全一致，不会触发校验和不同步。
- 战斗中动态刷出的怪物（孵化、复活、分节）走同一条换算路径，同样加成、同样确定。

---

## 三、实现：挂钩点

游戏里所有「怪物原始血量 → 最终血量」的换算都经过
`MegaCrit.Sts2.Core.Entities.Creatures.Creature` 的两个方法，本模组各挂一个 Harmony Postfix：

| 补丁 | 目标 | 作用 |
|---|---|---|
| 挂钩点 1 | `Creature.ScaleHpForMultiplayer`（静态） | 在换算结果上乘层数倍率。覆盖：多人刷怪缩放、煎蛋孵化、实验体复活、千足虫分节血量、事件文本血量预览 |
| 挂钩点 2 | `Creature.ScaleMonsterHpForMultiplayer`（实例） | 补齐**单人模式**常规刷怪（原版此方法在 `playerCount == 1` 时是空操作，根本不走挂钩点 1）。多人模式下此补丁直接跳过，防止重复计算 |

每只怪物出生时两个补丁**有且只有一个**生效，倍率只乘一次：

- 单人：挂钩点 2 → `原始血量 × (1 + 0.001 × 难度 × 层数)`
- 多人：挂钩点 1 → `原始血量 × 人数 × 按幕数系数 × (1 + 0.001 × 难度 × 层数)`

只加成**怪物**（`Creature.Monster != null`），玩家血量不受影响。
图鉴/怪物预览不加成（与原版预览不乘多人系数的行为一致）。

其他实现细节：

- **关键陷阱（曾导致首版失效）**：`CombatState.CreateCreature` 里 `AttachCreature`
  （给怪物绑定 `CombatState`）发生在 `ScaleMonsterHpForMultiplayer` **之后**，
  所以挂钩点 2 的 Postfix 执行时 `__instance.CombatState` 是 `null`。
  首版从 `CombatState.RunState` 取层数/难度拿到 null、倍率算成 1，静默不加成。
  现在一律走 `HpScaling.CurrentRunState()` 全局查找（`RunManager`），与怪物是否已绑定战斗无关。
- 层数与难度取自 `IRunState.TotalFloor` / `IRunState.AscensionLevel`；
  查不到 RunState 或 `NullRunState`（测试/预览场景）倍率为 1，安全无副作用。
- `RunState` 通过 `RunManager.RunStarted` 事件缓存 + `DebugOnlyGetState()`（反射调用，
  不硬引用，防游戏更新移除该方法）双通道获取。
- 血量写入走原版 `SetMaxHpInternal` / `SetCurrentHpInternal`，自带 999999999 上限保护。
- 日志写入 `%APPDATA%\SlayTheSpire2\logs\DeeperAndTankier.log`（每只怪物一行，含层数/难度/倍率）。

---

## 四、构建与安装

工程在 `src/`，用 .NET 9 SDK（本机为 SDK 10 亦可）构建：

```powershell
dotnet build src\DeeperAndTankier.csproj -c Release
```

构建后**自动安装**到 `C:\Program Files (x86)\Steam\steamapps\common\Slay the Spire 2\mods\DeeperAndTankier\`
（不想自动安装加 `-p:AutoInstall=false`；换盘/换机器改 csproj 顶部的 `Sts2GameDir`）。

安装后在游戏主菜单 → 模组 里启用 **愈深愈肉（Deeper and Tankier）**，开新局生效。

### 验证方法

- 看日志文件 `%APPDATA%\SlayTheSpire2\logs\DeeperAndTankier.log`，每刷一只怪一行，例如：
  `ScaleMonsterHpForMultiplayer: Cultist 第 16 层 A10 血量 55 → 63（倍率 1.16）`
- 直接看怪物血条数值：与原版差值 = 原版血量 × 0.001 × 难度 × 层数（向下取整）。

### 自动化自测（无需启动游戏）

`selftest/` 是独立测试程序，直接加载游戏程序集和模组的同一份补丁源码，
在真实 .NET 运行时里验证补丁触发、倍率数值、单人/多人路径，并检测 JIT 内联绕过：

```powershell
dotnet build selftest\SelfTest.csproj -c Release
.\selftest\bin\Release\DeeperAndTankierSelfTest.exe
```

全部 PASS 说明补丁逻辑正确；改公式或游戏版本更新后建议先跑一遍。

---

## 五、调整公式

想改成长速度只改一个常量（`src/HpScaling.cs`）：

```csharp
public const decimal GrowthPerDifficultyPerFloor = 0.001m;  // 每层每级难度 +0.1%
```

例如改成 0.002 则 A10 第 16 层 → +32%。改完重新 `dotnet build` 即可。
